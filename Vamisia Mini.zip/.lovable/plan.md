
# Final Portfolio Polish — Surgical Cleanup

Scope: presentation + prompt/data copy only. No changes to Amazon logic, `buildAmazonLink`, `activeRegion`, data fetching, routing, DeepSeek transport, or backup.

## 1. Results page (`src/routes/mini.tsx` → `CompleteView`)

- **Body text size:** bump "Psychological Profile" and "Motivation" body copy from `text-[0.95rem] sm:text-[1rem]` to `text-[1.1rem]` (keep `leading-[1.5]`, `text-[var(--editorial-ink)]`, font-sans).
- **Share row → Copy Link only:**
  - Remove the four network buttons (WhatsApp, Telegram, X, Facebook) entirely from `ShareRow`.
  - Keep only the "Copy link" button, centered, restyled as a clean primary/secondary CTA:
    - `inline-flex items-center gap-2 px-5 py-2.5 rounded-[4px] border-2 border-[var(--primary)] text-[var(--primary)] bg-white text-[0.8rem] uppercase tracking-[0.18em] font-semibold hover:bg-[var(--primary)] hover:text-white transition`
    - Lucide `Link` icon → swaps to `Check` + label "Copied" for ~1.6s after click.
  - Drop the "Share" eyebrow (single-button row doesn't need it).
  - Remove now-unused imports (`Share2`, network SVG imports if any) — keep `Link as LinkIcon, Check`.
- **Spacing:** keep the previously tightened `mb-4` / `mt-1 mb-5` values so the result fits in one mobile viewport.

## 2. Third-person output (He / She) — prompt + payload

- **Payload (`mini.tsx` around line 629):** ensure `gender` is included in `payload` sent to `analyzeProfile` (it's already collected in `bundle`). Derive and pass an explicit `pronoun_subject` / `pronoun_object` / `pronoun_possessive` triple from the selected `gender` screening answer:
  - male → `He / him / his`
  - female → `She / her / her`
  - any other/unspecified value → fallback `This person / this person / this person's` (never "they").
- **Prompt (`src/lib/deepseek.functions.ts` `SYSTEM_PROMPT`):** rewrite the language rule:
  - ABSOLUTE LANGUAGE RULE: use ONLY the third-person pronouns provided in the input (`pronoun_subject`, `pronoun_object`, `pronoun_possessive`). NEVER use "you", "your", "yours", "yourself". NEVER use "they", "them", "their", "theirs", "themselves". Any output containing forbidden pronouns is invalid — rewrite before returning.
  - Update `psychological_profile` opener from "This person is…" to "Start with `<pronoun_subject> is…`".
  - Keep JSON schema, negative constraint on `previous_gifts`, and 40-word / 20-word / two-sentence limits unchanged.
- **Sanitizer (`src/lib/journeyRouting.ts` `stripTheyThem`):** extend to also strip second-person pronouns → replace `you/your/yours/yourself` with the same pronoun set passed in. Add a small helper `enforcePronouns(text, pronouns)` and call it in `CompleteView` where `psychological_profile` and `motivation` are rendered (already using `stripTheyThem`) — swap the call.

## 3. Data copy — remove `they / their / them / themselves`

Sweep `src/data/maPart1.ts`, `maPart2.ts`, `maPart3.ts`, `maPart4.ts` (verbatim rule respected: only pronoun tokens change, no semantic rewrites):

- `their` → `this person's`
- `them` → `this person` (only where it refers to the subject; the one occurrence in `"want them to remember me"` in all four parts is the *gift recipient* — safe to replace with `this person`)
- `themselves` → `this person`
- `they` → `this person`
- Preserve capitalization at sentence start.

No changes to questions' *meaning* or option semantics — only pronoun substitution.

## 4. Out of scope (do not touch)

Amazon buttons and `buildAmazonLink`, `activeRegion` tracking, DeepSeek transport / API shape besides the prompt string, `surveyBackup`, budget calc, screening state machine, `__root.tsx`, `admin.tsx`, `styles.css`, `quiz.tsx`.

## Files touched

- `src/routes/mini.tsx` — body text sizes, `ShareRow` rewrite (Copy Link only), pronoun triple in payload, sanitizer call.
- `src/lib/deepseek.functions.ts` — SYSTEM_PROMPT language rule + opener.
- `src/lib/journeyRouting.ts` — extend sanitizer with `enforcePronouns` helper.
- `src/data/maPart1.ts`, `maPart2.ts`, `maPart3.ts`, `maPart4.ts` — pronoun substitutions only.
